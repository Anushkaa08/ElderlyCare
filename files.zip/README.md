# ElderlyCare – Monitoring Engine & Alert System (Member 3)

## 1. Introduction
**ElderlyCare** is a hardware-free elderly health monitoring system built as a college project.
This folder is the **Member 3 module**: it *simulates* vital signs, classifies them as
**Normal / Warning / Critical**, and creates meaningful alerts. It is a plain Python package that
Members 1, 2 and 4 can use without changing their own responsibilities.

> **Important:** every reading is simulated and every threshold is a *demonstration value*.
> They are **not** clinically validated medical guidelines. Do not use this for real patients.

## 2. Member 3 Responsibilities
- Simulate Heart Rate, SpO2, Body Temperature and Blood Pressure.
- Detect Normal, Warning and Critical conditions.
- Generate alerts with clear messages.
- Provide readings and alerts to Member 2 (FastAPI) and Member 4 (SQLite) in one fixed JSON structure.

Not in this module: FastAPI routes, React code, SQLite/SQL, hardware of any kind.

## 3. Technologies
Python 3.10+, standard library only (`datetime`, `random`, `typing`, `argparse`, `json`), and `pytest` for tests.

## 4. Folder Structure
```
monitoring/
├── __init__.py              # makes the folder a package; exports the main classes
├── config.py                # ALL thresholds, scenario settings, alert wording
├── vital_generator.py       # VitalSignsGenerator  - creates simulated readings
├── condition_checker.py     # ConditionChecker     - Normal / Warning / Critical
├── alert_engine.py          # AlertEngine          - builds alert dictionaries
├── monitoring_engine.py     # MonitoringEngine     - connects the three above
├── simulator.py             # terminal simulator (calls MonitoringEngine)
├── requirements.txt         # pytest
├── README.md                # this file
└── tests/
    ├── __init__.py
    ├── test_vital_generator.py
    ├── test_condition_checker.py
    ├── test_alert_engine.py
    └── test_monitoring_engine.py   # also covers the simulator
```
Generation, checking and alerting are kept in separate files on purpose.

## 5. Installation
Put the `monitoring/` folder in the root of your repository, then from that root:
```bash
pip install -r monitoring/requirements.txt
```
Always run commands from the folder that **contains** `monitoring/`.

## 6. Run the Simulator
```bash
python -m monitoring.simulator                      # normal scenario, every 5 s
python -m monitoring.simulator --scenario warning
python -m monitoring.simulator --scenario critical --interval 2
python -m monitoring.simulator --scenario random --patient-id 3
python -m monitoring.simulator --scenario random --cycles 5 --seed 42   # reproducible, stops after 5
```
Options: `--patient-id`, `--scenario {normal,warning,critical,random}`, `--interval` (seconds, default 5),
`--cycles` (0 = forever), `--seed`. Stop with **Ctrl+C**.

| Scenario | Behaviour |
|---|---|
| `normal` | All four vitals inside the normal range (always overall Normal, no alerts) |
| `warning` | 1–2 vitals in the Warning zone, others normal (always overall Warning) |
| `critical` | 1–2 vitals Critical, others normal or Warning (always overall Critical) |
| `random` | Each cycle randomly picks normal (70 %), warning (20 %) or critical (10 %) |

## 7. Run the Tests
```bash
pytest monitoring/tests -v
```
Tests use fixed readings or fixed seeds and never depend on random outcomes.

## 8. Example Output
Terminal:
```
====================================================================
Cycle #1 | 2026-11-25T08:30:00 | Patient ID: 1 | Scenario: critical
--------------------------------------------------------------------
Vital Sign        Reading                 Status
Heart Rate        101 BPM                 Warning
SpO2              99 %                    Normal
Temperature       34.9 °C                 Critical
Blood Pressure    138/94 mmHg             Warning
--------------------------------------------------------------------
Overall status: CRITICAL
Alerts (3):
  [Critical] Low Temperature: Critical low body temperature detected in simulated reading (34.9 °C).
  [Warning] High Heart Rate: Warning: high heart rate detected in simulated reading (101 BPM).
  [Warning] High Blood Pressure: Warning: high blood pressure detected in simulated reading (systolic 138 mmHg, diastolic 94 mmHg).
```
JSON returned by `run_cycle` (the agreed structure – **do not rename keys**):
```json
{
  "patient_id": 1,
  "readings": {
    "heart_rate": 101,
    "spo2": 99,
    "temperature": 34.9,
    "blood_pressure": {"systolic": 138, "diastolic": 94}
  },
  "vital_status": {
    "heart_rate": "Warning",
    "spo2": "Normal",
    "temperature": "Critical",
    "blood_pressure": "Warning"
  },
  "overall_status": "Critical",
  "alerts": [
    {
      "patient_id": 1,
      "alert_type": "Low Temperature",
      "severity": "Critical",
      "message": "Critical low body temperature detected in simulated reading (34.9 °C).",
      "timestamp": "2026-11-25T08:30:00"
    }
  ],
  "timestamp": "2026-11-25T08:30:00"
}
```
Units: Heart Rate = BPM, SpO2 = %, Temperature = °C, Blood Pressure = mmHg.
Status values are exactly `Normal`, `Warning`, `Critical`. Timestamps are ISO 8601.
Alert `alert_type` values: `Low/High Heart Rate`, `Low SpO2`, `Low/High Temperature`, `Low/High Blood Pressure`.

## 9. Importing the Engine
```python
from monitoring.monitoring_engine import MonitoringEngine

engine = MonitoringEngine()                       # MonitoringEngine(seed=42) for reproducible output
result = engine.run_cycle(patient_id=1, scenario="random")
```
`scenario` is `"normal"`, `"warning"`, `"critical"` or `"random"`. Invalid input raises `ValueError`.
To check readings you already have (no simulation): `engine.analyze_readings(patient_id, readings, timestamp=None)`.

## 10. Integration – Member 2 (FastAPI)
The engine does not depend on FastAPI. Member 2 only needs to call `run_cycle` inside their own route
(this is an example for Member 2's code, not part of this module):
```python
from fastapi import FastAPI, HTTPException
from monitoring.monitoring_engine import MonitoringEngine

app = FastAPI()
engine = MonitoringEngine()          # create once and reuse

@app.get("/api/monitor/{patient_id}")
def monitor(patient_id: int, scenario: str = "random"):
    try:
        return engine.run_cycle(patient_id=patient_id, scenario=scenario)  # plain dict -> JSON
    except ValueError as exc:         # bad patient_id or scenario
        raise HTTPException(status_code=422, detail=str(exc))
```

## 11. Integration – Member 4 (SQLite)
This module never touches a database. Member 4 receives the dictionary and stores the values with
**their own** functions (the two function names below are placeholders for Member 4's real functions):
```python
result = engine.run_cycle(patient_id=1, scenario="random")

bp = result["readings"]["blood_pressure"]
insert_vital_reading(                                   # Member 4's function
    patient_id=result["patient_id"],
    heart_rate=result["readings"]["heart_rate"],
    spo2=result["readings"]["spo2"],
    temperature=result["readings"]["temperature"],
    systolic=bp["systolic"],
    diastolic=bp["diastolic"],
    overall_status=result["overall_status"],
    timestamp=result["timestamp"],
)
for alert in result["alerts"]:                          # list of dicts, may be empty
    insert_alert(                                       # Member 4's function
        patient_id=alert["patient_id"],
        alert_type=alert["alert_type"],
        severity=alert["severity"],
        message=alert["message"],
        timestamp=alert["timestamp"],
    )
```

## 12. Compatibility with Member 1 (React)
Member 1 receives this same structure through Member 2's API. Keys never change, status text is always
`Normal` / `Warning` / `Critical`, timestamps are ISO 8601, and everything is JSON serialisable. This
module contains no frontend code.

## 13. Changing Thresholds
Edit `THRESHOLDS` in `config.py`. Each vital has nested `normal ⊆ warning ⊆ critical` ranges:
inside normal → Normal, inside warning but not normal → Warning, outside warning → Critical.
The simulator derives its ranges from these values, so it follows your changes automatically.
Invalid (non-nested) thresholds raise a `ValueError` at start-up.

## 14. Limitations
- All data is simulated and random; it does not represent a real person.
- Thresholds are demonstration values, not clinical guidelines, and are not age-/condition-adjusted.
- Each cycle is independent: no trends or gradual changes between cycles.
- Blood pressure produces one alert per cycle even if both numbers are abnormal (the message shows both).
- The engine only classifies and alerts; storing, history and display belong to Members 4, 2 and 1.
