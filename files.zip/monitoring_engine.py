"""
monitoring_engine.py - Main integration class (Member 3).

``MonitoringEngine`` connects VitalSignsGenerator -> ConditionChecker ->
AlertEngine and returns ONE dictionary in the agreed common structure shared
with Member 1 (React), Member 2 (FastAPI) and Member 4 (SQLite).

This module has no dependency on FastAPI, React or any database library.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from monitoring.alert_engine import AlertEngine
from monitoring.condition_checker import ConditionChecker
from monitoring.config import (
    DEFAULT_PATIENT_ID,
    DEFAULT_SCENARIO,
    current_timestamp,
    validate_patient_id,
)
from monitoring.vital_generator import VitalSignsGenerator


class MonitoringEngine:
    """Run complete simulated monitoring cycles.

    Example:
        >>> engine = MonitoringEngine(seed=1)
        >>> result = engine.run_cycle(patient_id=1, scenario="normal")
        >>> sorted(result)
        ['alerts', 'overall_status', 'patient_id', 'readings', 'timestamp', 'vital_status']
    """

    def __init__(self, seed: Optional[int] = None,
                 generator: Optional[VitalSignsGenerator] = None,
                 checker: Optional[ConditionChecker] = None,
                 alert_engine: Optional[AlertEngine] = None) -> None:
        self.generator = generator or VitalSignsGenerator(seed=seed)
        self.checker = checker or ConditionChecker()
        self.alert_engine = alert_engine or AlertEngine()

    def run_cycle(self, patient_id: int = DEFAULT_PATIENT_ID,
                  scenario: str = DEFAULT_SCENARIO) -> Dict[str, Any]:
        """Generate, evaluate and alert for one monitoring cycle.

        Args:
            patient_id: Positive integer patient identifier.
            scenario: "normal", "warning", "critical" or "random".

        Returns:
            The common output structure (see ``analyze_readings``).

        Raises:
            ValueError: for an invalid patient_id or scenario.
        """
        generated = self.generator.generate(patient_id=patient_id, scenario=scenario)
        return self.analyze_readings(generated["patient_id"], generated["readings"],
                                     generated["timestamp"])

    def analyze_readings(self, patient_id: int, readings: Dict[str, Any],
                         timestamp: Optional[str] = None) -> Dict[str, Any]:
        """Evaluate a given set of readings (no generation) and build the result.

        Useful for tests and for replaying fixed readings.

        Returns:
            ::

                {"patient_id": 1,
                 "readings": {"heart_rate": 78, "spo2": 97, "temperature": 36.8,
                              "blood_pressure": {"systolic": 120, "diastolic": 80}},
                 "vital_status": {"heart_rate": "Normal", "spo2": "Normal",
                                  "temperature": "Normal", "blood_pressure": "Normal"},
                 "overall_status": "Normal",
                 "alerts": [],
                 "timestamp": "2026-11-25T08:30:00"}
        """
        patient_id = validate_patient_id(patient_id)
        stamp = timestamp or current_timestamp()

        checked = self.checker.evaluate(readings)
        alerts = self.alert_engine.generate_alerts(patient_id, checked, stamp)

        return {
            "patient_id": patient_id,
            "readings": {
                "heart_rate": readings["heart_rate"],
                "spo2": readings["spo2"],
                "temperature": readings["temperature"],
                "blood_pressure": {
                    "systolic": readings["blood_pressure"]["systolic"],
                    "diastolic": readings["blood_pressure"]["diastolic"],
                },
            },
            "vital_status": checked["vital_status"],
            "overall_status": checked["overall_status"],
            "alerts": alerts,
            "timestamp": stamp,
        }
