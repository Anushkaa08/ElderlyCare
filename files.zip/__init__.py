"""ElderlyCare - Monitoring Engine & Alert System (Member 3).

All readings are simulated. Thresholds are demonstration values only and are
not clinically validated.
"""

from monitoring.alert_engine import AlertEngine
from monitoring.condition_checker import ConditionChecker
from monitoring.monitoring_engine import MonitoringEngine
from monitoring.vital_generator import VitalSignsGenerator

__all__ = ["AlertEngine", "ConditionChecker", "MonitoringEngine", "VitalSignsGenerator"]
__version__ = "1.0.0"
