"""Tests for ConditionChecker using fixed readings (no randomness)."""

import pytest

from monitoring.condition_checker import ConditionChecker

checker = ConditionChecker()


def make_readings(hr=78, spo2=97, temp=36.8, sys=120, dia=80):
    return {"heart_rate": hr, "spo2": spo2, "temperature": temp,
            "blood_pressure": {"systolic": sys, "diastolic": dia}}


def test_normal_heart_rate():
    assert checker.check_heart_rate(78) == {"status": "Normal", "direction": None}


@pytest.mark.parametrize("value, status", [(55, "Warning"), (45, "Critical"), (30, "Critical")])
def test_low_heart_rate(value, status):
    assert checker.check_heart_rate(value) == {"status": status, "direction": "low"}


@pytest.mark.parametrize("value, status", [(110, "Warning"), (130, "Critical"), (170, "Critical")])
def test_high_heart_rate(value, status):
    assert checker.check_heart_rate(value) == {"status": status, "direction": "high"}


@pytest.mark.parametrize("value", [60, 100])
def test_heart_rate_boundaries_are_normal(value):
    assert checker.check_heart_rate(value)["status"] == "Normal"


def test_normal_spo2():
    assert checker.check_spo2(97)["status"] == "Normal"


@pytest.mark.parametrize("value, status", [(92, "Warning"), (89, "Critical"), (80, "Critical")])
def test_low_spo2(value, status):
    assert checker.check_spo2(value) == {"status": status, "direction": "low"}


@pytest.mark.parametrize("value, status", [(37.8, "Warning"), (39.2, "Critical")])
def test_high_temperature(value, status):
    assert checker.check_temperature(value) == {"status": status, "direction": "high"}


@pytest.mark.parametrize("value, status", [(35.8, "Warning"), (34.5, "Critical")])
def test_low_temperature(value, status):
    assert checker.check_temperature(value) == {"status": status, "direction": "low"}


@pytest.mark.parametrize("sys, dia, status", [(145, 80, "Warning"), (185, 80, "Critical"),
                                              (120, 95, "Warning"), (120, 110, "Critical"),
                                              (170, 110, "Critical")])
def test_high_blood_pressure(sys, dia, status):
    result = checker.check_blood_pressure(sys, dia)
    assert result["status"] == status
    assert result["direction"] == "high"


@pytest.mark.parametrize("sys, dia, status", [(85, 70, "Warning"), (70, 70, "Critical"),
                                              (110, 55, "Warning"), (110, 40, "Critical")])
def test_low_blood_pressure(sys, dia, status):
    result = checker.check_blood_pressure(sys, dia)
    assert result["status"] == status
    assert result["direction"] == "low"


def test_blood_pressure_worst_component_wins():
    result = checker.check_blood_pressure(150, 110)  # systolic Warning, diastolic Critical
    assert result["status"] == "Critical"
    assert result["components"]["systolic"]["status"] == "Warning"
    assert result["components"]["diastolic"]["status"] == "Critical"


def test_all_normal_evaluation():
    result = checker.evaluate(make_readings())
    assert set(result["vital_status"].values()) == {"Normal"}
    assert result["overall_status"] == "Normal"


def test_multiple_abnormal_vitals_and_priority():
    # HR Normal, SpO2 Critical, Temperature Warning, BP Normal -> overall Critical
    result = checker.evaluate(make_readings(spo2=85, temp=37.9))
    assert result["vital_status"] == {"heart_rate": "Normal", "spo2": "Critical",
                                      "temperature": "Warning", "blood_pressure": "Normal"}
    assert result["overall_status"] == "Critical"


def test_overall_warning_when_no_critical():
    result = checker.evaluate(make_readings(hr=110, temp=37.9))
    assert result["overall_status"] == "Warning"


@pytest.mark.parametrize("statuses, expected", [
    (["Normal", "Normal"], "Normal"),
    (["Normal", "Warning"], "Warning"),
    (["Warning", "Critical", "Normal"], "Critical"),
    ([], "Normal"),
])
def test_worst_status_priority(statuses, expected):
    assert ConditionChecker.worst_status(statuses) == expected


def test_status_strings_are_exact():
    statuses = set()
    for hr in (78, 110, 140):
        statuses.add(checker.check_heart_rate(hr)["status"])
    assert statuses == {"Normal", "Warning", "Critical"}


@pytest.mark.parametrize("bad", [None, "80", True, float("nan")])
def test_non_numeric_reading_rejected(bad):
    with pytest.raises(ValueError):
        checker.check_heart_rate(bad)


def test_missing_reading_rejected():
    with pytest.raises(ValueError):
        checker.evaluate({"heart_rate": 70})


def test_unknown_vital_rejected():
    with pytest.raises(ValueError):
        checker.classify("glucose", 5)
