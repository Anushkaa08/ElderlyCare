"""
simulator.py - Terminal simulator for the monitoring engine (Member 3).

Run from the folder that CONTAINS the ``monitoring`` package::

    python -m monitoring.simulator --scenario critical --interval 2

The simulator only displays results; all monitoring logic lives in
``MonitoringEngine``. Press Ctrl+C to stop.
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

# Allow "python monitoring/simulator.py" as well as "python -m monitoring.simulator".
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from monitoring.config import (  # noqa: E402
    DEFAULT_INTERVAL_SECONDS,
    DEFAULT_PATIENT_ID,
    DEFAULT_SCENARIO,
    DISCLAIMER,
    SCENARIOS,
)
from monitoring.monitoring_engine import MonitoringEngine  # noqa: E402

LINE_WIDTH = 68


def format_result(result: Dict[str, Any], cycle: Optional[int] = None,
                  scenario: Optional[str] = None) -> str:
    """Turn one monitoring result into a readable multi-line string."""
    readings = result["readings"]
    status = result["vital_status"]
    bp = readings["blood_pressure"]

    title = f"Cycle #{cycle} | " if cycle is not None else ""
    title += f"{result['timestamp']} | Patient ID: {result['patient_id']}"
    if scenario:
        title += f" | Scenario: {scenario}"

    rows = [
        ("Heart Rate", f"{readings['heart_rate']} BPM", status["heart_rate"]),
        ("SpO2", f"{readings['spo2']} %", status["spo2"]),
        ("Temperature", f"{readings['temperature']} °C", status["temperature"]),
        ("Blood Pressure", f"{bp['systolic']}/{bp['diastolic']} mmHg", status["blood_pressure"]),
    ]
    lines: List[str] = ["=" * LINE_WIDTH, title, "-" * LINE_WIDTH,
                        f"{'Vital Sign':<18}{'Reading':<24}Status"]
    lines += [f"{name:<18}{value:<24}{state}" for name, value, state in rows]
    lines.append("-" * LINE_WIDTH)
    lines.append(f"Overall status: {result['overall_status'].upper()}")

    alerts = result["alerts"]
    if alerts:
        lines.append(f"Alerts ({len(alerts)}):")
        lines += [f"  [{a['severity']}] {a['alert_type']}: {a['message']}" for a in alerts]
    else:
        lines.append("Alerts: none")
    return "\n".join(lines)


def run_simulator(patient_id: int = DEFAULT_PATIENT_ID,
                  scenario: str = DEFAULT_SCENARIO,
                  interval: float = DEFAULT_INTERVAL_SECONDS,
                  cycles: int = 0,
                  seed: Optional[int] = None,
                  engine: Optional[MonitoringEngine] = None,
                  sleep: Callable[[float], None] = time.sleep,
                  out: Callable[[str], None] = print) -> int:
    """Run monitoring cycles until Ctrl+C (or ``cycles`` is reached).

    Args:
        cycles: Number of cycles to run; 0 means run until stopped.
        sleep / out: Injectable for testing.

    Returns:
        Number of cycles attempted.
    """
    engine = engine or MonitoringEngine(seed=seed)
    count = 0
    out(f"ElderlyCare monitoring simulator | patient {patient_id} | scenario '{scenario}' "
        f"| every {interval:g}s | Ctrl+C to stop")
    out(DISCLAIMER)
    try:
        while cycles == 0 or count < cycles:
            count += 1
            try:
                result = engine.run_cycle(patient_id=patient_id, scenario=scenario)
                out(format_result(result, cycle=count, scenario=scenario))
            except Exception as exc:  # keep the simulator alive on any cycle error
                out(f"[ERROR] Monitoring cycle {count} failed: {exc}")
            if cycles and count >= cycles:
                break
            sleep(interval)
    except KeyboardInterrupt:
        out("\nSimulator stopped by user (Ctrl+C).")
    return count


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m monitoring.simulator",
        description="ElderlyCare terminal simulator (simulated readings only).")
    parser.add_argument("--patient-id", type=int, default=DEFAULT_PATIENT_ID,
                        help="positive integer patient id (default: %(default)s)")
    parser.add_argument("--scenario", choices=SCENARIOS, default=DEFAULT_SCENARIO,
                        help="simulation scenario (default: %(default)s)")
    parser.add_argument("--interval", type=float, default=DEFAULT_INTERVAL_SECONDS,
                        help="seconds between cycles (default: %(default)s)")
    parser.add_argument("--cycles", type=int, default=0,
                        help="stop after N cycles; 0 = run until Ctrl+C (default: 0)")
    parser.add_argument("--seed", type=int, default=None,
                        help="random seed for reproducible output")
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    """Command-line entry point."""
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.interval <= 0:
        parser.error("--interval must be greater than 0")
    if args.cycles < 0:
        parser.error("--cycles cannot be negative")
    if args.patient_id < 1:
        parser.error("--patient-id must be a positive integer")
    run_simulator(args.patient_id, args.scenario, args.interval, args.cycles, args.seed)
    return 0


if __name__ == "__main__":
    sys.exit(main())
