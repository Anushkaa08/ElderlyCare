"""Tests for VitalSignsGenerator (simulation only, no judging logic)."""

import json
import re

import pytest

from monitoring.config import (
    DIRECTION_HIGH, DIRECTION_LOW, SCENARIOS, STATUS_CRITICAL, STATUS_NORMAL,
    STATUS_WARNING, THRESHOLDS,
)
from monitoring.vital_generator import VitalSignsGenerator

ISO_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$")


def inside(value, key, band):
    lo, hi = THRESHOLDS[key][band]
    return lo <= value <= hi


def test_same_seed_gives_same_readings():
    a = VitalSignsGenerator(seed=7).generate(1, "random", timestamp="t")
    b = VitalSignsGenerator(seed=7).generate(1, "random", timestamp="t")
    assert a == b


def test_reseed_restarts_sequence():
    gen = VitalSignsGenerator(seed=3)
    first = gen.generate(1, "critical", timestamp="t")
    gen.reseed(3)
    assert gen.generate(1, "critical", timestamp="t") == first


def test_output_structure_and_json_serializable():
    data = VitalSignsGenerator(seed=1).generate(patient_id=5, scenario="normal")
    assert set(data) == {"patient_id", "scenario", "readings", "timestamp"}
    assert set(data["readings"]) == {"heart_rate", "spo2", "temperature", "blood_pressure"}
    assert set(data["readings"]["blood_pressure"]) == {"systolic", "diastolic"}
    assert ISO_PATTERN.match(data["timestamp"])
    json.dumps(data)


def test_patient_id_is_configurable():
    gen = VitalSignsGenerator(seed=1)
    assert gen.generate(patient_id=42)["patient_id"] == 42


@pytest.mark.parametrize("bad_id", [0, -1, "1", 1.5, None, True])
def test_invalid_patient_id_rejected(bad_id):
    with pytest.raises(ValueError):
        VitalSignsGenerator(seed=1).generate(patient_id=bad_id)


def test_invalid_scenario_rejected():
    with pytest.raises(ValueError):
        VitalSignsGenerator(seed=1).generate(scenario="chaos")


def test_scenario_name_is_case_insensitive():
    assert VitalSignsGenerator(seed=1).generate(scenario=" NORMAL ")["scenario"] == "normal"


def test_normal_scenario_stays_in_normal_ranges():
    for seed in range(200):
        r = VitalSignsGenerator(seed=seed).generate(1, "normal")["readings"]
        assert inside(r["heart_rate"], "heart_rate", "normal")
        assert inside(r["spo2"], "spo2", "normal")
        assert inside(r["temperature"], "temperature", "normal")
        assert inside(r["blood_pressure"]["systolic"], "systolic_bp", "normal")
        assert inside(r["blood_pressure"]["diastolic"], "diastolic_bp", "normal")


def test_random_scenario_resolves_to_a_concrete_scenario():
    seen = {VitalSignsGenerator(seed=s).generate(1, "random")["scenario"] for s in range(100)}
    assert seen <= {"normal", "warning", "critical"}
    assert "normal" in seen


@pytest.mark.parametrize("direction", [DIRECTION_LOW, DIRECTION_HIGH])
@pytest.mark.parametrize("level", [STATUS_WARNING, STATUS_CRITICAL])
def test_heart_rate_abnormal_levels(level, direction):
    gen = VitalSignsGenerator(seed=11)
    n_lo, n_hi = THRESHOLDS["heart_rate"]["normal"]
    w_lo, w_hi = THRESHOLDS["heart_rate"]["warning"]
    for _ in range(50):
        value = gen.generate_heart_rate(level, direction)
        if level == STATUS_WARNING:
            assert (w_lo <= value < n_lo) if direction == DIRECTION_LOW else (n_hi < value <= w_hi)
        else:
            assert value < w_lo if direction == DIRECTION_LOW else value > w_hi


def test_spo2_only_supports_low_abnormal_values():
    gen = VitalSignsGenerator(seed=2)
    assert gen.generate_spo2(STATUS_CRITICAL) < THRESHOLDS["spo2"]["warning"][0]
    with pytest.raises(ValueError):
        gen.generate_spo2(STATUS_WARNING, DIRECTION_HIGH)


def test_temperature_has_one_decimal_and_high_low_support():
    gen = VitalSignsGenerator(seed=4)
    high = gen.generate_temperature(STATUS_CRITICAL, DIRECTION_HIGH)
    low = gen.generate_temperature(STATUS_CRITICAL, DIRECTION_LOW)
    assert high > THRESHOLDS["temperature"]["warning"][1]
    assert low < THRESHOLDS["temperature"]["warning"][0]
    assert round(high, 1) == high and round(low, 1) == low


def test_blood_pressure_generated_together_in_same_direction():
    gen = VitalSignsGenerator(seed=5)
    high = gen.generate_blood_pressure(STATUS_CRITICAL, DIRECTION_HIGH)
    low = gen.generate_blood_pressure(STATUS_CRITICAL, DIRECTION_LOW)
    assert high["systolic"] > THRESHOLDS["systolic_bp"]["warning"][1]
    assert high["diastolic"] > THRESHOLDS["diastolic_bp"]["warning"][1]
    assert low["systolic"] < THRESHOLDS["systolic_bp"]["warning"][0]
    assert low["diastolic"] < THRESHOLDS["diastolic_bp"]["warning"][0]


def test_unknown_level_or_direction_rejected():
    gen = VitalSignsGenerator(seed=1)
    with pytest.raises(ValueError):
        gen.generate_heart_rate("Severe")
    with pytest.raises(ValueError):
        gen.generate_heart_rate(STATUS_WARNING, "sideways")


@pytest.mark.parametrize("scenario", SCENARIOS)
def test_every_scenario_generates_json_serializable_data(scenario):
    json.dumps(VitalSignsGenerator(seed=9).generate(1, scenario))


def test_custom_thresholds_change_normal_values():
    import copy
    custom = copy.deepcopy(THRESHOLDS)
    custom["heart_rate"]["normal"] = (70, 72)
    gen = VitalSignsGenerator(seed=1, thresholds=custom)
    assert all(70 <= gen.generate_heart_rate(STATUS_NORMAL) <= 72 for _ in range(30))


def test_invalid_custom_thresholds_rejected():
    import copy
    bad = copy.deepcopy(THRESHOLDS)
    bad["spo2"]["normal"] = (80, 100)  # normal wider than warning
    with pytest.raises(ValueError):
        VitalSignsGenerator(thresholds=bad)
