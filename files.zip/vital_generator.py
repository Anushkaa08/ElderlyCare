"""
vital_generator.py - Simulated vital-sign generation (Member 3).

``VitalSignsGenerator`` creates *simulated* Heart Rate, SpO2, Body Temperature
and Blood Pressure readings. It never judges readings (that is the
ConditionChecker's job) and never touches a database.

Ranges for every level are derived from ``config.THRESHOLDS``, so changing a
threshold automatically changes what the simulator produces.
"""

from __future__ import annotations

import copy
import math
import random
from typing import Any, Dict, Optional, Tuple

from monitoring.config import (
    CRITICAL_EXTRA_WARNING_CHANCE,
    CRITICAL_VITAL_COUNT,
    DEFAULT_PATIENT_ID,
    DEFAULT_SCENARIO,
    DIRECTION_HIGH,
    DIRECTION_LOW,
    NORMAL_RANGE_MARGIN,
    RANDOM_SCENARIO_WEIGHTS,
    SCENARIO_CRITICAL,
    SCENARIO_NORMAL,
    SCENARIO_RANDOM,
    SCENARIO_WARNING,
    SCENARIOS,
    STATUS_CRITICAL,
    STATUS_NORMAL,
    STATUS_PRIORITY,
    STATUS_WARNING,
    THRESHOLDS,
    VITAL_KEYS,
    WARNING_VITAL_COUNT,
    current_timestamp,
    validate_patient_id,
    validate_thresholds,
)

Range = Tuple[float, float]


class VitalSignsGenerator:
    """Generate simulated, JSON-serialisable vital-sign readings.

    Args:
        seed: Optional integer seed. The same seed always produces the same
            sequence of readings (useful for tests and demos).
        thresholds: Optional custom thresholds (defaults to ``config.THRESHOLDS``).

    Example:
        >>> gen = VitalSignsGenerator(seed=42)
        >>> data = gen.generate(patient_id=1, scenario="normal")
        >>> sorted(data)
        ['patient_id', 'readings', 'scenario', 'timestamp']
    """

    def __init__(self, seed: Optional[int] = None,
                 thresholds: Optional[Dict[str, Dict[str, Any]]] = None) -> None:
        self.thresholds = copy.deepcopy(thresholds if thresholds is not None else THRESHOLDS)
        validate_thresholds(self.thresholds)
        self._rng = random.Random(seed)

    # ------------------------------------------------------------------ API
    def reseed(self, seed: Optional[int]) -> None:
        """Restart the random sequence from ``seed``."""
        self._rng.seed(seed)

    def generate(self, patient_id: int = DEFAULT_PATIENT_ID,
                 scenario: str = DEFAULT_SCENARIO,
                 timestamp: Optional[str] = None) -> Dict[str, Any]:
        """Generate one monitoring cycle of simulated readings.

        Args:
            patient_id: Positive integer patient identifier.
            scenario: "normal", "warning", "critical" or "random".
            timestamp: Optional ISO 8601 timestamp (defaults to now).

        Returns:
            ``{"patient_id", "scenario", "readings", "timestamp"}`` where
            ``scenario`` is the concrete scenario used (never "random") and
            ``readings`` follows the agreed structure.

        Raises:
            ValueError: for an invalid patient_id or scenario.
        """
        patient_id = validate_patient_id(patient_id)
        resolved = self._resolve_scenario(scenario)
        plan = self._plan_levels(resolved)

        readings: Dict[str, Any] = {
            "heart_rate": self.generate_heart_rate(plan["heart_rate"]),
            "spo2": self.generate_spo2(plan["spo2"]),
            "temperature": self.generate_temperature(plan["temperature"]),
            "blood_pressure": self.generate_blood_pressure(plan["blood_pressure"]),
        }
        return {
            "patient_id": patient_id,
            "scenario": resolved,
            "readings": readings,
            "timestamp": timestamp or current_timestamp(),
        }

    def generate_heart_rate(self, level: str = STATUS_NORMAL,
                            direction: Optional[str] = None) -> int:
        """Heart rate in BPM. ``level``: Normal/Warning/Critical; ``direction``: "low"/"high"."""
        return self._value_for("heart_rate", level, direction)[0]

    def generate_spo2(self, level: str = STATUS_NORMAL,
                      direction: Optional[str] = None) -> int:
        """Oxygen saturation in %. Only a "low" direction exists for Warning/Critical."""
        return self._value_for("spo2", level, direction)[0]

    def generate_temperature(self, level: str = STATUS_NORMAL,
                             direction: Optional[str] = None) -> float:
        """Body temperature in °C (one decimal place)."""
        return self._value_for("temperature", level, direction)[0]

    def generate_blood_pressure(self, level: str = STATUS_NORMAL,
                                direction: Optional[str] = None) -> Dict[str, int]:
        """Systolic and diastolic pressure in mmHg, generated together.

        For abnormal levels both values move in the same direction (for
        example both high), like a real high/low blood-pressure episode.
        """
        systolic, used = self._value_for("systolic_bp", level, direction)
        if level == STATUS_NORMAL:
            diastolic = self._normal_value("diastolic_bp")
        else:
            ranges = self._ranges("diastolic_bp", level)
            if used in ranges:
                diastolic = self._draw("diastolic_bp", *ranges[used])
            else:  # no matching abnormal range for diastolic -> keep it normal
                diastolic = self._normal_value("diastolic_bp")
        return {"systolic": systolic, "diastolic": diastolic}

    # ------------------------------------------------------------ scenarios
    def _resolve_scenario(self, scenario: str) -> str:
        """Validate the scenario name; pick a concrete one for "random"."""
        name = str(scenario).strip().lower()
        if name not in SCENARIOS:
            raise ValueError(f"Unknown scenario {scenario!r}. Choose from: {', '.join(SCENARIOS)}")
        if name == SCENARIO_RANDOM:
            names = sorted(RANDOM_SCENARIO_WEIGHTS)
            weights = [RANDOM_SCENARIO_WEIGHTS[n] for n in names]
            return self._rng.choices(names, weights=weights, k=1)[0]
        return name

    def _plan_levels(self, scenario: str) -> Dict[str, str]:
        """Decide the target status level for each of the four vitals."""
        plan = {vital: STATUS_NORMAL for vital in VITAL_KEYS}
        if scenario == SCENARIO_WARNING:
            count = self._rng.randint(*WARNING_VITAL_COUNT)
            for vital in self._rng.sample(list(VITAL_KEYS), count):
                plan[vital] = STATUS_WARNING
        elif scenario == SCENARIO_CRITICAL:
            count = self._rng.randint(*CRITICAL_VITAL_COUNT)
            critical = set(self._rng.sample(list(VITAL_KEYS), count))
            for vital in VITAL_KEYS:
                if vital in critical:
                    plan[vital] = STATUS_CRITICAL
                elif self._rng.random() < CRITICAL_EXTRA_WARNING_CHANCE:
                    plan[vital] = STATUS_WARNING
        # SCENARIO_NORMAL: everything stays Normal
        return plan

    # ------------------------------------------------------- value drawing
    def _ranges(self, key: str, level: str) -> Dict[str, Range]:
        """Return the usable {direction: (lo, hi)} ranges for a Warning/Critical level."""
        if level not in (STATUS_WARNING, STATUS_CRITICAL):
            raise ValueError(f"Abnormal level must be Warning or Critical, got {level!r}")
        t = self.thresholds[key]
        p = t["precision"]
        step = 10 ** -p
        n_lo, n_hi = t["normal"]
        w_lo, w_hi = t["warning"]
        c_lo, c_hi = t["critical"]
        if level == STATUS_WARNING:
            candidates = {DIRECTION_LOW: (w_lo, n_lo - step), DIRECTION_HIGH: (n_hi + step, w_hi)}
        else:
            candidates = {DIRECTION_LOW: (c_lo, w_lo - step), DIRECTION_HIGH: (w_hi + step, c_hi)}
        usable: Dict[str, Range] = {}
        for direction, (lo, hi) in candidates.items():
            lo, hi = round(lo, p), round(hi, p)
            if lo <= hi:
                usable[direction] = (lo, hi)
        return usable

    def _normal_bounds(self, key: str) -> Range:
        """Middle part of the normal range (avoids sitting on the borderline)."""
        t = self.thresholds[key]
        lo, hi = t["normal"]
        margin = (hi - lo) * NORMAL_RANGE_MARGIN
        if t["precision"] == 0:
            new_lo, new_hi = math.ceil(lo + margin), math.floor(hi - margin)
        else:
            new_lo = max(lo, round(lo + margin, t["precision"]))
            new_hi = min(hi, round(hi - margin, t["precision"]))
        return (lo, hi) if new_lo > new_hi else (new_lo, new_hi)

    def _draw(self, key: str, lo: float, hi: float) -> Any:
        """Draw one random value in [lo, hi] using the vital's precision."""
        p = self.thresholds[key]["precision"]
        if p == 0:
            return self._rng.randint(math.ceil(lo), math.floor(hi))
        return round(self._rng.uniform(lo, hi), p)

    def _normal_value(self, key: str) -> Any:
        return self._draw(key, *self._normal_bounds(key))

    def _value_for(self, key: str, level: str,
                   direction: Optional[str] = None) -> Tuple[Any, Optional[str]]:
        """Return ``(value, direction_used)`` for a threshold key and status level."""
        if level not in STATUS_PRIORITY:
            raise ValueError(f"Unknown level {level!r}")
        if direction not in (None, DIRECTION_LOW, DIRECTION_HIGH):
            raise ValueError(f"direction must be 'low', 'high' or None, got {direction!r}")
        if level == STATUS_NORMAL:
            return self._normal_value(key), None
        ranges = self._ranges(key, level)
        if not ranges:
            raise ValueError(f"No {level} range available for '{key}'")
        if direction is None:
            direction = self._rng.choice(sorted(ranges))
        elif direction not in ranges:
            raise ValueError(f"No {direction} {level} range available for '{key}'")
        return self._draw(key, *ranges[direction]), direction
