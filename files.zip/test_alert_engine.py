"""Tests for AlertEngine using fixed readings (no randomness)."""

import json

import pytest

from monitoring.alert_engine import AlertEngine
from monitoring.condition_checker import ConditionChecker

TS = "2026-11-25T08:30:00"
checker = ConditionChecker()
engine = AlertEngine()


def alerts_for(hr=78, spo2=97, temp=36.8, sys=120, dia=80, patient_id=1):
    readings = {"heart_rate": hr, "spo2": spo2, "temperature": temp,
                "blood_pressure": {"systolic": sys, "diastolic": dia}}
    return engine.generate_alerts(patient_id, checker.evaluate(readings), TS)


def test_no_alerts_for_normal_readings():
    assert alerts_for() == []


def test_critical_low_spo2_alert_content():
    alerts = alerts_for(spo2=85)
    assert len(alerts) == 1
    alert = alerts[0]
    assert alert["patient_id"] == 1
    assert alert["alert_type"] == "Low SpO2"
    assert alert["severity"] == "Critical"
    assert alert["timestamp"] == TS
    assert "Critical low oxygen saturation detected in simulated reading" in alert["message"]


def test_alert_has_exactly_the_agreed_fields():
    assert set(alerts_for(hr=140)[0]) == {"patient_id", "alert_type", "severity", "message", "timestamp"}


def test_warning_alert():
    alert = alerts_for(hr=110)[0]
    assert alert["alert_type"] == "High Heart Rate"
    assert alert["severity"] == "Warning"
    assert alert["message"].startswith("Warning:")


@pytest.mark.parametrize("kwargs, alert_type", [
    ({"hr": 40}, "Low Heart Rate"), ({"hr": 150}, "High Heart Rate"),
    ({"spo2": 85}, "Low SpO2"),
    ({"temp": 39.5}, "High Temperature"), ({"temp": 34.5}, "Low Temperature"),
    ({"sys": 190}, "High Blood Pressure"), ({"sys": 70}, "Low Blood Pressure"),
])
def test_alert_types(kwargs, alert_type):
    assert [a["alert_type"] for a in alerts_for(**kwargs)] == [alert_type]


def test_multiple_alerts_in_one_cycle_most_severe_first():
    alerts = alerts_for(hr=110, spo2=85, temp=37.9)
    assert [a["alert_type"] for a in alerts] == ["Low SpO2", "High Heart Rate", "High Temperature"]
    assert [a["severity"] for a in alerts] == ["Critical", "Warning", "Warning"]


def test_blood_pressure_creates_only_one_alert_even_if_both_values_abnormal():
    alerts = alerts_for(sys=190, dia=115)
    assert len(alerts) == 1
    assert "systolic 190 mmHg" in alerts[0]["message"]
    assert "diastolic 115 mmHg" in alerts[0]["message"]


def test_no_duplicate_alerts_per_vital():
    alerts = alerts_for(hr=150, spo2=80, temp=40.0, sys=190, dia=115)
    types = [a["alert_type"] for a in alerts]
    assert len(types) == len(set(types)) == 4


def test_alerts_use_given_patient_id_and_are_json_serializable():
    alerts = alerts_for(spo2=85, patient_id=42)
    assert alerts[0]["patient_id"] == 42
    json.dumps(alerts)


def test_alert_message_contains_value_and_unit():
    assert "39.5 °C" in alerts_for(temp=39.5)[0]["message"]
    assert "85%" in alerts_for(spo2=85)[0]["message"]
    assert "150 BPM" in alerts_for(hr=150)[0]["message"]


def test_invalid_input_rejected():
    with pytest.raises(ValueError):
        engine.generate_alerts(1, {"no": "details"}, TS)
    with pytest.raises(ValueError):
        engine.generate_alerts(0, checker.evaluate(
            {"heart_rate": 70, "spo2": 97, "temperature": 36.8,
             "blood_pressure": {"systolic": 120, "diastolic": 80}}), TS)
