"""
alert_engine.py - Turn ConditionChecker results into alerts (Member 3).

``AlertEngine`` only creates alerts for conditions the ConditionChecker has
marked Warning or Critical. Normal readings never produce alerts.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from monitoring.config import (
    ALERT_DISPLAY,
    ALERT_MESSAGE_TEMPLATES,
    STATUS_NORMAL,
    STATUS_PRIORITY,
    VITAL_KEYS,
    current_timestamp,
    validate_patient_id,
)


class AlertEngine:
    """Create meaningful alerts from a condition-check result.

    Each alert is a flat, JSON-serialisable dictionary::

        {"patient_id": 1, "alert_type": "Low SpO2", "severity": "Critical",
         "message": "...", "timestamp": "2026-11-25T08:30:00"}
    """

    def __init__(self, templates: Optional[Dict[str, str]] = None) -> None:
        self.templates = dict(templates if templates is not None else ALERT_MESSAGE_TEMPLATES)

    def generate_alerts(self, patient_id: int, check_result: Dict[str, Any],
                        timestamp: Optional[str] = None) -> List[Dict[str, Any]]:
        """Create alerts for every abnormal vital in one monitoring cycle.

        Args:
            patient_id: Positive integer patient identifier.
            check_result: Output of ``ConditionChecker.evaluate``.
            timestamp: ISO 8601 timestamp shared by all alerts of this cycle.

        Returns:
            List of alert dictionaries, most severe first. At most one alert
            is created per vital sign. Empty list when everything is Normal.
        """
        patient_id = validate_patient_id(patient_id)
        try:
            details = check_result["details"]
        except (KeyError, TypeError) as exc:
            raise ValueError("check_result must come from ConditionChecker.evaluate()") from exc
        stamp = timestamp or current_timestamp()

        alerts: List[Dict[str, Any]] = []
        seen = set()  # guards against duplicate alerts for one vital in a cycle
        for vital in VITAL_KEYS:
            info = details.get(vital)
            if info is None or info["status"] == STATUS_NORMAL or vital in seen:
                continue
            seen.add(vital)
            alerts.append(self._build_alert(patient_id, vital, info, stamp))

        # Most severe first; sort is stable so equal severities keep vital order.
        alerts.sort(key=lambda alert: -STATUS_PRIORITY[alert["severity"]])
        return alerts

    # ------------------------------------------------------------- helpers
    def _build_alert(self, patient_id: int, vital: str,
                     info: Dict[str, Any], timestamp: str) -> Dict[str, Any]:
        display = ALERT_DISPLAY[vital]
        direction = info["direction"]
        severity = info["status"]
        message = self.templates[severity].format(
            direction=direction,
            description=display["description"],
            value_text=self._format_value(vital, info),
        )
        return {
            "patient_id": patient_id,
            "alert_type": f"{direction.capitalize()} {display['name']}",
            "severity": severity,
            "message": message,
            "timestamp": timestamp,
        }

    @staticmethod
    def _format_value(vital: str, info: Dict[str, Any]) -> str:
        """Readable value with its unit, e.g. '85%', '142 BPM', '39.2 °C'."""
        unit = info["unit"]
        if vital == "blood_pressure":
            bp = info["value"]
            return (f"systolic {bp['systolic']} {unit}, "
                    f"diastolic {bp['diastolic']} {unit}")
        return f"{info['value']}{unit}" if unit == "%" else f"{info['value']} {unit}"
