"""
condition_checker.py - Classify readings as Normal / Warning / Critical (Member 3).

``ConditionChecker`` only judges values using ``config.THRESHOLDS``. It does
not generate readings and does not create alerts.
"""

from __future__ import annotations

import copy
import math
from typing import Any, Dict, Iterable, Optional

from monitoring.config import (
    BLOOD_PRESSURE_COMPONENTS,
    DIRECTION_HIGH,
    DIRECTION_LOW,
    STATUS_CRITICAL,
    STATUS_NORMAL,
    STATUS_PRIORITY,
    STATUS_WARNING,
    THRESHOLDS,
    validate_thresholds,
)


class ConditionChecker:
    """Evaluate vital signs against configurable thresholds.

    Example:
        >>> checker = ConditionChecker()
        >>> checker.check_heart_rate(130)
        {'status': 'Warning', 'direction': 'high'}
    """

    def __init__(self, thresholds: Optional[Dict[str, Dict[str, Any]]] = None) -> None:
        self.thresholds = copy.deepcopy(thresholds if thresholds is not None else THRESHOLDS)
        validate_thresholds(self.thresholds)

    # ------------------------------------------------------ single values
    def classify(self, key: str, value: float) -> Dict[str, Optional[str]]:
        """Classify one value for a threshold key (e.g. "heart_rate", "systolic_bp").

        Returns:
            ``{"status": "Normal"|"Warning"|"Critical", "direction": "low"|"high"|None}``
            ``direction`` is None for Normal readings.
        """
        if key not in self.thresholds:
            raise ValueError(f"Unknown vital '{key}'")
        if isinstance(value, bool) or not isinstance(value, (int, float)) or math.isnan(value):
            raise ValueError(f"Reading for '{key}' must be a number, got {value!r}")

        t = self.thresholds[key]
        n_lo, n_hi = t["normal"]
        w_lo, w_hi = t["warning"]

        if n_lo <= value <= n_hi:
            return {"status": STATUS_NORMAL, "direction": None}
        direction = DIRECTION_LOW if value < n_lo else DIRECTION_HIGH
        status = STATUS_WARNING if w_lo <= value <= w_hi else STATUS_CRITICAL
        return {"status": status, "direction": direction}

    def check_heart_rate(self, value: float) -> Dict[str, Optional[str]]:
        """Classify heart rate (BPM)."""
        return self.classify("heart_rate", value)

    def check_spo2(self, value: float) -> Dict[str, Optional[str]]:
        """Classify oxygen saturation (%)."""
        return self.classify("spo2", value)

    def check_temperature(self, value: float) -> Dict[str, Optional[str]]:
        """Classify body temperature (°C)."""
        return self.classify("temperature", value)

    def check_blood_pressure(self, systolic: float, diastolic: float) -> Dict[str, Any]:
        """Classify systolic and diastolic pressure; the worse one decides the status.

        Returns:
            ``{"status", "direction", "components": {"systolic": {...}, "diastolic": {...}}}``
            ``direction`` belongs to the worse component (systolic wins ties).
        """
        components = {
            "systolic": self.classify("systolic_bp", systolic),
            "diastolic": self.classify("diastolic_bp", diastolic),
        }
        worst = max(BLOOD_PRESSURE_COMPONENTS,
                    key=lambda name: STATUS_PRIORITY[components[name]["status"]])
        return {
            "status": components[worst]["status"],
            "direction": components[worst]["direction"],
            "components": components,
        }

    # ------------------------------------------------------- full evaluation
    @staticmethod
    def worst_status(statuses: Iterable[str]) -> str:
        """Return the most severe status (CRITICAL > WARNING > NORMAL)."""
        result = STATUS_NORMAL
        for status in statuses:
            if status not in STATUS_PRIORITY:
                raise ValueError(f"Unknown status {status!r}")
            if STATUS_PRIORITY[status] > STATUS_PRIORITY[result]:
                result = status
        return result

    def evaluate(self, readings: Dict[str, Any]) -> Dict[str, Any]:
        """Evaluate a complete readings dictionary.

        Args:
            readings: ``{"heart_rate", "spo2", "temperature",
                "blood_pressure": {"systolic", "diastolic"}}``

        Returns:
            ``{"vital_status": {...}, "overall_status": str, "details": {...}}``.
            ``details`` (direction, value, unit per vital) is consumed by the
            AlertEngine and is not part of the final public output.

        Raises:
            ValueError: if a reading is missing or not numeric.
        """
        try:
            heart_rate = readings["heart_rate"]
            spo2 = readings["spo2"]
            temperature = readings["temperature"]
            systolic = readings["blood_pressure"]["systolic"]
            diastolic = readings["blood_pressure"]["diastolic"]
        except (KeyError, TypeError) as exc:
            raise ValueError(
                "readings must contain heart_rate, spo2, temperature and "
                "blood_pressure{systolic, diastolic}"
            ) from exc

        t = self.thresholds
        details: Dict[str, Dict[str, Any]] = {
            "heart_rate": {**self.check_heart_rate(heart_rate),
                           "value": heart_rate, "unit": t["heart_rate"]["unit"]},
            "spo2": {**self.check_spo2(spo2),
                     "value": spo2, "unit": t["spo2"]["unit"]},
            "temperature": {**self.check_temperature(temperature),
                            "value": temperature, "unit": t["temperature"]["unit"]},
            "blood_pressure": {**self.check_blood_pressure(systolic, diastolic),
                               "value": {"systolic": systolic, "diastolic": diastolic},
                               "unit": t["systolic_bp"]["unit"]},
        }
        vital_status = {name: info["status"] for name, info in details.items()}
        return {
            "vital_status": vital_status,
            "overall_status": self.worst_status(vital_status.values()),
            "details": details,
        }
