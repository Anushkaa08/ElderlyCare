"""Tests for MonitoringEngine (integration) and the terminal simulator."""

import json

import pytest

from monitoring.monitoring_engine import MonitoringEngine
from monitoring.simulator import format_result, main, run_simulator

TS = "2026-11-25T08:30:00"
TOP_LEVEL_KEYS = {"patient_id", "readings", "vital_status", "overall_status", "alerts", "timestamp"}


def fixed(hr=78, spo2=97, temp=36.8, sys=120, dia=80):
    return {"heart_rate": hr, "spo2": spo2, "temperature": temp,
            "blood_pressure": {"systolic": sys, "diastolic": dia}}


def test_exact_agreed_structure_for_normal_readings():
    result = MonitoringEngine().analyze_readings(1, fixed(), TS)
    assert result == {
        "patient_id": 1,
        "readings": {"heart_rate": 78, "spo2": 97, "temperature": 36.8,
                     "blood_pressure": {"systolic": 120, "diastolic": 80}},
        "vital_status": {"heart_rate": "Normal", "spo2": "Normal",
                         "temperature": "Normal", "blood_pressure": "Normal"},
        "overall_status": "Normal",
        "alerts": [],
        "timestamp": TS,
    }


def test_overall_status_priority_with_alerts():
    result = MonitoringEngine().analyze_readings(1, fixed(spo2=85, temp=37.9), TS)
    assert result["overall_status"] == "Critical"
    assert result["vital_status"]["temperature"] == "Warning"
    assert len(result["alerts"]) == 2


def test_multiple_abnormal_vitals():
    result = MonitoringEngine().analyze_readings(3, fixed(hr=150, spo2=85, temp=39.5, sys=190, dia=110), TS)
    assert set(result["vital_status"].values()) == {"Critical"}
    assert len(result["alerts"]) == 4


@pytest.mark.parametrize("patient_id", [1, 2, 42, 1000])
def test_different_patient_ids(patient_id):
    result = MonitoringEngine(seed=1).run_cycle(patient_id=patient_id, scenario="critical")
    assert result["patient_id"] == patient_id
    assert all(alert["patient_id"] == patient_id for alert in result["alerts"])


def test_invalid_inputs_rejected():
    engine = MonitoringEngine(seed=1)
    with pytest.raises(ValueError):
        engine.run_cycle(patient_id=0)
    with pytest.raises(ValueError):
        engine.run_cycle(scenario="unknown")


@pytest.mark.parametrize("seed", range(60))
def test_normal_scenario_has_no_alerts(seed):
    result = MonitoringEngine(seed=seed).run_cycle(1, "normal")
    assert set(result) == TOP_LEVEL_KEYS
    assert result["overall_status"] == "Normal"
    assert result["alerts"] == []
    assert set(result["vital_status"].values()) == {"Normal"}


@pytest.mark.parametrize("seed", range(60))
def test_warning_scenario_is_warning(seed):
    result = MonitoringEngine(seed=seed).run_cycle(1, "warning")
    assert result["overall_status"] == "Warning"
    assert 1 <= len(result["alerts"]) <= 2
    assert all(alert["severity"] == "Warning" for alert in result["alerts"])


@pytest.mark.parametrize("seed", range(60))
def test_critical_scenario_is_critical(seed):
    result = MonitoringEngine(seed=seed).run_cycle(1, "critical")
    assert result["overall_status"] == "Critical"
    assert any(alert["severity"] == "Critical" for alert in result["alerts"])
    assert result["alerts"][0]["severity"] == "Critical"  # most severe first


def test_random_scenario_produces_all_kinds_of_status():
    statuses = {MonitoringEngine(seed=s).run_cycle(1, "random")["overall_status"] for s in range(200)}
    assert statuses == {"Normal", "Warning", "Critical"}


@pytest.mark.parametrize("scenario", ["normal", "warning", "critical", "random"])
def test_output_is_json_serializable_and_consistent(scenario):
    result = MonitoringEngine(seed=5).run_cycle(1, scenario)
    assert json.loads(json.dumps(result)) == result
    assert set(result) == TOP_LEVEL_KEYS
    assert set(result["readings"]) == {"heart_rate", "spo2", "temperature", "blood_pressure"}
    assert set(result["vital_status"]) == {"heart_rate", "spo2", "temperature", "blood_pressure"}
    assert set(result["vital_status"].values()) <= {"Normal", "Warning", "Critical"}
    assert len(result["timestamp"]) == 19 and result["timestamp"][10] == "T"


def test_alerts_exist_only_for_abnormal_vitals():
    for seed in range(50):
        result = MonitoringEngine(seed=seed).run_cycle(1, "random")
        abnormal = sum(1 for s in result["vital_status"].values() if s != "Normal")
        assert len(result["alerts"]) == abnormal


def test_same_seed_is_reproducible():
    a = MonitoringEngine(seed=99).run_cycle(1, "random")
    b = MonitoringEngine(seed=99).run_cycle(1, "random")
    a["timestamp"] = b["timestamp"] = TS
    for alert in a["alerts"] + b["alerts"]:
        alert["timestamp"] = TS
    assert a == b


# ------------------------------------------------------------- simulator
def test_simulator_runs_requested_cycles_and_displays_everything():
    lines, sleeps = [], []
    count = run_simulator(patient_id=7, scenario="critical", interval=0.5, cycles=2, seed=1,
                          sleep=sleeps.append, out=lines.append)
    text = "\n".join(lines)
    assert count == 2
    assert sleeps == [0.5]  # sleeps between cycles only
    for expected in ("Patient ID: 7", "Heart Rate", "SpO2", "Temperature", "Blood Pressure",
                     "Overall status: CRITICAL", "Alerts ("):
        assert expected in text


def test_simulator_stops_cleanly_on_ctrl_c():
    def interrupt(_seconds):
        raise KeyboardInterrupt

    lines = []
    count = run_simulator(cycles=0, seed=1, sleep=interrupt, out=lines.append)
    assert count == 1
    assert "stopped by user" in lines[-1]


def test_simulator_survives_cycle_errors():
    class BrokenEngine:
        def run_cycle(self, **_kwargs):
            raise RuntimeError("boom")

    lines = []
    count = run_simulator(cycles=2, engine=BrokenEngine(), sleep=lambda _s: None, out=lines.append)
    assert count == 2
    assert sum("[ERROR]" in line for line in lines) == 2


def test_format_result_without_alerts():
    result = MonitoringEngine().analyze_readings(1, fixed(), TS)
    text = format_result(result, cycle=1, scenario="normal")
    assert "Alerts: none" in text and "Overall status: NORMAL" in text


def test_main_runs_with_arguments():
    assert main(["--scenario", "warning", "--interval", "0.01", "--cycles", "1", "--seed", "3"]) == 0
