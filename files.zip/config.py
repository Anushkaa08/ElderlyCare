"""
config.py - Central configuration for the ElderlyCare Monitoring Engine (Member 3).

Everything that can be tuned lives in this file: thresholds, scenario
behaviour, display labels, alert message templates and a few tiny shared
helpers. No other file hardcodes a threshold.

IMPORTANT: All thresholds below are *demonstration values* for a simulated
elderly-monitoring application. They are NOT clinically validated medical
guidelines and must never be used for real patient care.

How thresholds work
-------------------
Every vital has three nested ranges (inclusive on both ends):

    critical (simulation limits)  ⊇  warning  ⊇  normal

* value inside ``normal``                  -> "Normal"
* value inside ``warning`` but not normal  -> "Warning"
* value outside ``warning``                -> "Critical"

The ``critical`` range gives the most extreme values the *simulator* will
produce; the checker still treats anything outside ``warning`` as Critical.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Tuple

Range = Tuple[float, float]

DISCLAIMER: str = (
    "All readings are SIMULATED for demonstration. Thresholds are NOT "
    "clinically validated medical guidelines."
)

# --------------------------------------------------------------------------
# General settings
# --------------------------------------------------------------------------
DEFAULT_PATIENT_ID: int = 1
DEFAULT_INTERVAL_SECONDS: float = 5.0
DEFAULT_SCENARIO: str = "normal"

# --------------------------------------------------------------------------
# Status values (exact strings shared with the frontend / backend / database)
# --------------------------------------------------------------------------
STATUS_NORMAL: str = "Normal"
STATUS_WARNING: str = "Warning"
STATUS_CRITICAL: str = "Critical"

# Higher number = more severe. Overall status: CRITICAL > WARNING > NORMAL.
STATUS_PRIORITY: Dict[str, int] = {
    STATUS_NORMAL: 0,
    STATUS_WARNING: 1,
    STATUS_CRITICAL: 2,
}

DIRECTION_LOW: str = "low"
DIRECTION_HIGH: str = "high"

# --------------------------------------------------------------------------
# Scenarios
# --------------------------------------------------------------------------
SCENARIO_NORMAL: str = "normal"
SCENARIO_WARNING: str = "warning"
SCENARIO_CRITICAL: str = "critical"
SCENARIO_RANDOM: str = "random"
SCENARIOS: Tuple[str, ...] = (
    SCENARIO_NORMAL,
    SCENARIO_WARNING,
    SCENARIO_CRITICAL,
    SCENARIO_RANDOM,
)

# "random" scenario: chance of picking each concrete scenario per cycle.
RANDOM_SCENARIO_WEIGHTS: Dict[str, float] = {
    SCENARIO_NORMAL: 0.70,
    SCENARIO_WARNING: 0.20,
    SCENARIO_CRITICAL: 0.10,
}

# "warning" scenario: how many vitals (min, max) are pushed into Warning.
WARNING_VITAL_COUNT: Tuple[int, int] = (1, 2)
# "critical" scenario: how many vitals (min, max) are pushed into Critical.
CRITICAL_VITAL_COUNT: Tuple[int, int] = (1, 2)
# "critical" scenario: chance that each remaining vital is at Warning level.
CRITICAL_EXTRA_WARNING_CHANCE: float = 0.30
# Normal readings are drawn from the middle of the normal range; this is the
# fraction of the range trimmed from each end (0.10 = 10 %).
NORMAL_RANGE_MARGIN: float = 0.10

# --------------------------------------------------------------------------
# Vital names
# --------------------------------------------------------------------------
# The four vitals reported to Members 1, 2 and 4 (do not rename).
VITAL_KEYS: Tuple[str, ...] = ("heart_rate", "spo2", "temperature", "blood_pressure")
# Blood pressure is checked as two separate values.
BLOOD_PRESSURE_COMPONENTS: Tuple[str, ...] = ("systolic", "diastolic")

# --------------------------------------------------------------------------
# Demonstration thresholds  (EDIT HERE to change behaviour)
# --------------------------------------------------------------------------
THRESHOLDS: Dict[str, Dict[str, Any]] = {
    "heart_rate": {
        "unit": "BPM",
        "precision": 0,          # decimals used when simulating
        "normal": (60, 100),
        "warning": (50, 120),    # Warning: 50-59 or 101-120
        "critical": (30, 180),   # Critical: <50 or >120
    },
    "spo2": {
        "unit": "%",
        "precision": 0,
        "normal": (95, 100),
        "warning": (90, 100),    # Warning: 90-94 (no "high" side: max is 100 %)
        "critical": (70, 100),   # Critical: <90
    },
    "temperature": {
        "unit": "°C",
        "precision": 1,
        "normal": (36.1, 37.5),
        "warning": (35.5, 38.5),  # Warning: 35.5-36.0 or 37.6-38.5
        "critical": (33.0, 41.0),  # Critical: <35.5 or >38.5
    },
    "systolic_bp": {
        "unit": "mmHg",
        "precision": 0,
        "normal": (90, 130),
        "warning": (80, 160),    # Warning: 80-89 or 131-160
        "critical": (60, 220),   # Critical: <80 or >160
    },
    "diastolic_bp": {
        "unit": "mmHg",
        "precision": 0,
        "normal": (60, 85),
        "warning": (50, 100),    # Warning: 50-59 or 86-100
        "critical": (35, 130),   # Critical: <50 or >100
    },
}

# --------------------------------------------------------------------------
# Alert wording
# --------------------------------------------------------------------------
# "name" builds alert_type (e.g. "Low SpO2"); "description" is used in messages.
ALERT_DISPLAY: Dict[str, Dict[str, str]] = {
    "heart_rate": {"name": "Heart Rate", "description": "heart rate"},
    "spo2": {"name": "SpO2", "description": "oxygen saturation"},
    "temperature": {"name": "Temperature", "description": "body temperature"},
    "blood_pressure": {"name": "Blood Pressure", "description": "blood pressure"},
}

ALERT_MESSAGE_TEMPLATES: Dict[str, str] = {
    STATUS_WARNING: "Warning: {direction} {description} detected in simulated reading ({value_text}).",
    STATUS_CRITICAL: "Critical {direction} {description} detected in simulated reading ({value_text}).",
}

_REQUIRED_THRESHOLD_KEYS = ("heart_rate", "spo2", "temperature", "systolic_bp", "diastolic_bp")
_REQUIRED_THRESHOLD_FIELDS = ("unit", "precision", "normal", "warning", "critical")


# --------------------------------------------------------------------------
# Small shared helpers (kept here so every module uses identical behaviour)
# --------------------------------------------------------------------------
def current_timestamp() -> str:
    """Return the current local time as an ISO 8601 string, e.g. 2026-11-25T08:30:00."""
    return datetime.now().isoformat(timespec="seconds")


def validate_patient_id(patient_id: Any) -> int:
    """Return ``patient_id`` if it is a positive integer, otherwise raise ValueError."""
    if isinstance(patient_id, bool) or not isinstance(patient_id, int) or patient_id < 1:
        raise ValueError(f"patient_id must be a positive integer, got {patient_id!r}")
    return patient_id


def validate_thresholds(thresholds: Dict[str, Dict[str, Any]]) -> None:
    """Check that a thresholds dictionary is complete and correctly nested.

    Raises:
        ValueError: if a vital or field is missing, or the ranges are not
            nested as ``critical ⊇ warning ⊇ normal``.
    """
    for key in _REQUIRED_THRESHOLD_KEYS:
        if key not in thresholds:
            raise ValueError(f"Missing thresholds for '{key}'")
        entry = thresholds[key]
        for field in _REQUIRED_THRESHOLD_FIELDS:
            if field not in entry:
                raise ValueError(f"Thresholds for '{key}' are missing '{field}'")
        n_lo, n_hi = entry["normal"]
        w_lo, w_hi = entry["warning"]
        c_lo, c_hi = entry["critical"]
        if not (c_lo <= w_lo <= n_lo <= n_hi <= w_hi <= c_hi):
            raise ValueError(
                f"Thresholds for '{key}' must satisfy "
                "critical_min <= warning_min <= normal_min <= normal_max <= warning_max <= critical_max"
            )
